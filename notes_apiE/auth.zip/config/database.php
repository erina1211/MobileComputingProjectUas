<?php
$conn = mysqli_connect("localhost","tommy","1802005","restaurant_app");
// Membuat koneksi ke database MySQL
// host: localhost
// user: tommy
// password: 1802005
// database: restaurant_app

if(!$conn){
    die("Connection Failed: ". mysqli_connect_error());
    // Jika koneksi gagal, tampilkan pesan error dan hentikan program
}
