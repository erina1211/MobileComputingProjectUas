<?php
require_once '../config/cors.php';
// Mengizinkan akses API dari domain lain (CORS)

require_once '../config/database.php';
// Menghubungkan ke database (variabel $conn)

$data = json_decode(file_get_contents("php://input"), true);
// Mengambil data JSON dari body request lalu mengubahnya menjadi array PHP

$email = $data['email'];
// Menyimpan email yang dikirim dari Flutter

$password = $data['password'];
// Menyimpan password yang dikirim dari Flutter

$res = mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");
// Query ke database untuk mencari user berdasarkan email

$user = mysqli_fetch_assoc($res);
// Mengambil hasil query sebagai array асosiatif

if ($user && password_verify($password,$user['password'])) {
  // Mengecek:
  // 1. User ditemukan
  // 2. Password input cocok dengan password hash di database

  echo json_encode(["success"=>true,"user"=>$user]);
  // Jika login berhasil, kirim response success true dan data user
} else {
  echo json_encode(["success"=>false]);
  // Jika login gagal, kirim response success false
}
